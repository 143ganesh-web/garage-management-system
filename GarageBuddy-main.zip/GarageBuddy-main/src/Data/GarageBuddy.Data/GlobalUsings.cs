﻿#pragma warning disable SA1200 // Using directives should be placed correctly
global using System;

global using static GarageBuddy.Common.Constants.MessageConstants;
#pragma warning restore SA1200 // Using directives should be placed correctly
