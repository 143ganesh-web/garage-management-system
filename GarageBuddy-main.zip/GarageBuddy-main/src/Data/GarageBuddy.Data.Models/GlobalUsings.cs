﻿#pragma warning disable SA1200 // Using directives should be placed correctly
global using System;
global using System.ComponentModel.DataAnnotations;
global using System.ComponentModel.DataAnnotations.Schema;

global using GarageBuddy.Data.Common.Models;

global using static GarageBuddy.Common.Constants.GlobalValidationConstants;
#pragma warning restore SA1200 // Using directives should be placed correctly
