﻿namespace GarageBuddy.Data.Models.Enums;

public enum JobStatusEnum
{
    New = 1,
    InProgress = 2,
    Completed = 3,
    Cancelled = 4,
}
