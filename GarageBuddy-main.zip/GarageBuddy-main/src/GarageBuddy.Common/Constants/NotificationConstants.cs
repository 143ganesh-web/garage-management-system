﻿namespace GarageBuddy.Common.Constants
{
    public static class NotificationConstants
    {
        public const string NotifyError = "NotifyError";
        public const string NotifyWarning = "NotifyWarning";
        public const string NotifyInfo = "NotifyInfo";
        public const string NotifySuccess = "NotifySuccess";
    }
}
