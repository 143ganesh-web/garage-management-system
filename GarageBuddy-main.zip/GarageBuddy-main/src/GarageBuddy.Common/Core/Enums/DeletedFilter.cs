﻿namespace GarageBuddy.Common.Core.Enums
{
    public enum DeletedFilter
    {
        // All = 0,
        NotDeleted = 1,
        Deleted = 2,
    }
}
