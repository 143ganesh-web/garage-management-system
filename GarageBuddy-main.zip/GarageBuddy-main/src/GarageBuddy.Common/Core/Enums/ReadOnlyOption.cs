﻿namespace GarageBuddy.Common.Core.Enums
{
    public enum ReadOnlyOption
    {
        Normal = 0,
        ReadOnly = 1,
    }
}
