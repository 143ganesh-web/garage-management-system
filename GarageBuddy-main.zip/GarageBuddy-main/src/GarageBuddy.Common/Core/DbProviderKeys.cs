﻿namespace GarageBuddy.Common.Core
{
    public class DbProviderKeys
    {
        public const string SqlServer = "mssql";

        /*public const string Npgsql = "postgresql";

        public const string MySql = "mysql";

        public const string Oracle = "oracle";

        public const string SqLite = "sqlite";*/
    }
}
