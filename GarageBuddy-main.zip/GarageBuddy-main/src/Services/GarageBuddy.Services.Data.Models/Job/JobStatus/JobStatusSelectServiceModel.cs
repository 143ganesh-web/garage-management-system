﻿namespace GarageBuddy.Services.Data.Models.Job.JobStatus
{
    public class JobStatusSelectServiceModel
    {
        public int Id { get; set; }

        public string StatusName { get; set; } = null!;
    }
}
