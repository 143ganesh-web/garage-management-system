﻿namespace GarageBuddy.Services.Data.Models.Job.JobItemType
{
    public class JobItemTypeSelectServiceModel
    {
        public string Id { get; set; } = null!;

        public string JobTypeName { get; set; } = null!;
    }
}
