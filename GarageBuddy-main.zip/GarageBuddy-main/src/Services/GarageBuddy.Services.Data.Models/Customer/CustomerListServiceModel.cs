﻿namespace GarageBuddy.Services.Data.Models.Customer
{
    public class CustomerListServiceModel : CustomerServiceModel
    {
        public string UserName { get; set; } = null!;
    }
}
