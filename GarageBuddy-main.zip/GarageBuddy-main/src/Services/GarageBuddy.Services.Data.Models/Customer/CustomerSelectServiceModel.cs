﻿namespace GarageBuddy.Services.Data.Models.Customer
{
    public class CustomerSelectServiceModel
    {
        public string Id { get; set; } = null!;

        public string CustomerName { get; set; } = null!;

        public string Phone { get; set; } = null!;
    }
}
