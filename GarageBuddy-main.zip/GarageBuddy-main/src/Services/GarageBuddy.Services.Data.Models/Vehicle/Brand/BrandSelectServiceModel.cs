﻿namespace GarageBuddy.Services.Data.Models.Vehicle.Brand
{
    public class BrandSelectServiceModel
    {
        public string Id { get; set; } = null!;

        public string BrandName { get; set; } = null!;
    }
}
