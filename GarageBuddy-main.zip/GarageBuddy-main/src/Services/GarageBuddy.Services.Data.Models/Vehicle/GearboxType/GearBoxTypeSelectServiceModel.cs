﻿namespace GarageBuddy.Services.Data.Models.Vehicle.GearboxType
{
    public class GearboxTypeSelectServiceModel
    {
        public int Id { get; set; }

        public string GearboxTypeName { get; set; } = null!;
    }
}
