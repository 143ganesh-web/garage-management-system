﻿namespace GarageBuddy.Services.Data.Models.Vehicle.DriveType
{
    public class DriveTypeSelectServiceModel
    {
        public int Id { get; set; }

        public string DriveTypeName { get; set; } = null!;
    }
}
