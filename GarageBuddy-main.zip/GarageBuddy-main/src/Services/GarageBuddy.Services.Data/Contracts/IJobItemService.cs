﻿namespace GarageBuddy.Services.Data.Contracts
{
    public interface IJobItemService
    {
    }
}
