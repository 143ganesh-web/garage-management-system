﻿#pragma warning disable SA1200 // Using directives should be placed correctly
global using System;
global using System.ComponentModel.DataAnnotations;

global using AutoMapper;

global using GarageBuddy.Common.Attributes;
global using GarageBuddy.Services.Mapping;
global using GarageBuddy.Web.ViewModels.Admin.Base;
#pragma warning restore SA1200 // Using directives should be placed correctly\
