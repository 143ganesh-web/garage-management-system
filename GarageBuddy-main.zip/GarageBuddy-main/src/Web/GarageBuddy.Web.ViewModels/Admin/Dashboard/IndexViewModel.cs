﻿namespace GarageBuddy.Web.ViewModels.Admin.Dashboard
{
    public class IndexViewModel
    {
        public int SettingsCount { get; set; }
    }
}
