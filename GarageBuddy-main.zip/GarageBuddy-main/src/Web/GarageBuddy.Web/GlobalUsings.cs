﻿#pragma warning disable SA1200 // Using directives should be placed correctly
global using System;
global using System.Collections.Generic;
global using System.Threading.Tasks;

global using Ganss.Xss;

global using static GarageBuddy.Common.Constants.ControllersAndActionsConstants;
global using static GarageBuddy.Common.Constants.GlobalConstants;
global using static GarageBuddy.Common.Constants.MessageConstants;
global using static GarageBuddy.Common.Constants.NotificationConstants;
#pragma warning restore SA1200 // Using directives should be placed correctly\
